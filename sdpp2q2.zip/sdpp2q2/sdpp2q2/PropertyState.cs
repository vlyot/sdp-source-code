﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sdpp2q2
{
    public interface PropertyState
    {
        void Offer(Buyer buyer);
        void BuyerPullout();
        void VendorPullout();
        void SignContract(Buyer buyer);
        void PayPrice();
    }

}
