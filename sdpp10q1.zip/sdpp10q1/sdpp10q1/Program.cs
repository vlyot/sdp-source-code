﻿Console.WriteLine("Creating Warrior:");
CharacterCreator warriorCreator = new WarriorCreator();
warriorCreator.createCharacter();

Console.WriteLine("\nCreating Wizard:");
CharacterCreator wizardCreator = new WizardCreator();
wizardCreator.createCharacter();

public abstract class CharacterCreator
{
    public void createCharacter()
    {
        chooseRace();
        assignAbilites();
        isSpellcaster();
        assignSpells();
        finalizeCharacter();
    }
    public void chooseRace()
    {
        Console.WriteLine("Choosing race....");
    }

    public abstract void assignAbilites();
    public abstract bool isSpellcaster();

    public abstract void assignSpells();

    public void finalizeCharacter()
    {
        Console.WriteLine("Character creation complete.");
    }

}

public class WarriorCreator : CharacterCreator
{
    public override void assignAbilites()
    {
        Console.WriteLine("Assigning Warrior abilities: Block, Shield Bash");
    }
    public override bool isSpellcaster()
    {
        return false;
    }
    public override void assignSpells()
    {
        
    }
}

public class WizardCreator : CharacterCreator
{
    public override void assignAbilites()
    {
        Console.WriteLine("Assigning Wizard abilities: Focus, Quick Cast");
    }
    public override bool isSpellcaster()
    {
        return true;
    }
    public override void assignSpells()
    {
        Console.WriteLine("Assigning spells: Fireball, Slow, Magic Missle");
    }
}