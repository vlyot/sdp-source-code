﻿using System;

public abstract class Quest
{
    protected int reward;
    protected int timeLimit;
    protected int number;

    public Quest(int reward, int timeLimit, int number)
    {
        this.reward = reward;
        this.timeLimit = timeLimit;
        this.number = number;
    }

    public abstract string getDescription();
}

public class RivendellVillageQuest : Quest
{
    public RivendellVillageQuest() : base(8, 4, 3) { }  // Reward, Time Limit, Number of Monsters

    public override string getDescription()
    {
        return $"Kill {number} Pixie monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

public class RivendellCityQuest : Quest
{
    public RivendellCityQuest() : base(15, 6, 2) { }  // Reward, Time Limit, Number of Monsters

    public override string getDescription()
    {
        return $"Kill {number} Thief monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

public class MordorVillageQuest : Quest
{
    public MordorVillageQuest() : base(10, 5, 6) { }  // Reward, Time Limit, Number of Monsters

    public override string getDescription()
    {
        return $"Kill {number} Giant Rat monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

public class MordorCityQuest : Quest
{
    public MordorCityQuest() : base(20, 7, 4) { }  // Reward, Time Limit, Number of Monsters

    public override string getDescription()
    {
        return $"Kill {number} Bandit monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

public interface QuestFactory
{
    Quest createQuest(string type);
}

public class RivendellQuestFactory : QuestFactory
{
    public Quest createQuest(string type)
    {
        if (type.Equals("village", StringComparison.OrdinalIgnoreCase))
        {
            return new RivendellVillageQuest();
        }
        else if (type.Equals("city", StringComparison.OrdinalIgnoreCase))
        {
            return new RivendellCityQuest();
        }
        return null;
    }
}

public class MordorQuestFactory : QuestFactory
{
    public Quest createQuest(string type)
    {
        if (type.Equals("village", StringComparison.OrdinalIgnoreCase))
        {
            return new MordorVillageQuest();
        }
        else if (type.Equals("city", StringComparison.OrdinalIgnoreCase))
        {
            return new MordorCityQuest();
        }
        return null;
    }
}

public class QuestGenerator
{
    private QuestFactory questFactory;

    public QuestGenerator(QuestFactory questFactory)
    {
        this.questFactory = questFactory;
    }

    public void launchQuest(string type)
    {
        Quest quest = questFactory.createQuest(type);
        if (quest != null)
        {
            Console.WriteLine(quest.getDescription());
        }
        else
        {
            Console.WriteLine("No quest available for the specified type.");
        }
    }
}

public class Program
{
    public static void Main()
    {
        QuestGenerator questGenerator = new QuestGenerator(new RivendellQuestFactory());
        questGenerator.launchQuest("village");
        questGenerator.launchQuest("city");

        questGenerator = new QuestGenerator(new MordorQuestFactory());
        questGenerator.launchQuest("village");
        questGenerator.launchQuest("city");
    }
}
