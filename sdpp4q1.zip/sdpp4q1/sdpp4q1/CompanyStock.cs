﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sdpp4q1
{
    public class CompanyStock : iCompanystock
    {
        private List<Customer> Customers;
        public string Name;
        private double currentPrice;

        public double CurrentPrice
        {
            get { return currentPrice; }
            set
            {
                if (currentPrice != value)
                {
                    currentPrice = value;
                    notifyObservers(); // Notify customers when price changes
                }
            }
        }

        public CompanyStock(string s, double p)
        {
            this.Name = s;
            this.currentPrice = p;
            Customers = new List<Customer>();
        }

        public void registerObserver(Customer c)
        {
            Customers.Add(c);
        }

        public void removeObserver(Customer c)
        {
            Customers.Remove(c);
        }

        public void notifyObservers()
        {
            foreach (Customer c in Customers)
            {
                c.update(this.Name, currentPrice);
            }
        }
    }

}
