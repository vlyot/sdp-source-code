﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sdpp4q1
{
    public class Customer : icustomer
    {
        public string name;
        private List<CompanyStock> stocks;
        public Customer(string name) {
            this.name = name;
            this.stocks = new List<CompanyStock>();
        }

        public void update(string name, double p)
        {
            Console.WriteLine(this.name + " is notified that " + name + " price is set to $"+p);
        }

        public void addStock(CompanyStock cs)
        {
            stocks.Add(cs);
            cs.registerObserver(this);
        }

        public void removeStock(CompanyStock cs)
        {
            stocks.Remove(cs);
            cs.removeObserver(this);
        }
    }
}
