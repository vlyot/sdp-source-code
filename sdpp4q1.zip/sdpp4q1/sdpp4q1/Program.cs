﻿// See https://aka.ms/new-console-template for more information
using sdpp4q1;
using System;

CompanyStock apple = new CompanyStock("Apple", 233.0);
CompanyStock tesla = new CompanyStock("Tesla", 261.63);
CompanyStock singtel = new CompanyStock("SingTel", 3.23);

Customer john = new Customer("John");
john.addStock(apple);
john.addStock(tesla);

Customer mary = new Customer("Mary");
mary.addStock(apple);
mary.addStock(singtel);

apple.CurrentPrice = 225.5;
tesla.CurrentPrice = 264.2;
john.removeStock(apple);
apple.CurrentPrice = 255.1;


interface iCompanystock
{
    void registerObserver(Customer c);
    void removeObserver(Customer c);
    void notifyObservers();
}

interface icustomer
{
    void update(string name, double currentPrice);
}
