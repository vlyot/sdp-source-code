﻿using System;

// Interface representing the abstract factory
public interface QuestFactory
{
    Quest createQuest(string type);
}

// Abstract base class representing a quest
public abstract class Quest
{
    protected int reward;
    protected int timeLimit;
    protected int number;
    protected string monster;

    public Quest(int number, int timeLimit, string monster)
    {
        this.number = number;
        this.timeLimit = timeLimit;
        this.monster = monster;
    }

    // Calculates the reward based on difficulty, number, and time limit
    public void calculateReward(int difficulty)
    {
        reward = difficulty * number - timeLimit;
    }

    // Returns a description of the quest
    public abstract string getDescription();
}

// Concrete quest classes for Rivendell area quests
public class RivendellVillageQuest : Quest
{
    public RivendellVillageQuest() : base(3, 5, "Pixie") { }

    public override string getDescription()
    {
        return $"Kill {number} {monster} monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

public class RivendellCityQuest : Quest
{
    public RivendellCityQuest() : base(2, 5, "Thief") { }

    public override string getDescription()
    {
        return $"Kill {number} {monster} monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

// Concrete quest classes for Mordor area quests
public class MordorVillageQuest : Quest
{
    public MordorVillageQuest() : base(5, 3, "Giant Rat") { }

    public override string getDescription()
    {
        return $"Kill {number} {monster} monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

public class MordorCityQuest : Quest
{
    public MordorCityQuest() : base(5, 3, "Bandit") { }

    public override string getDescription()
    {
        return $"Kill {number} {monster} monsters in {timeLimit} days for {reward} gold pieces.";
    }
}

// Concrete factory for Rivendell quests
public class RivendellQuestFactory : QuestFactory
{
    public Quest createQuest(string type)
    {
        Quest quest = null;
        if (type.Equals("village", StringComparison.OrdinalIgnoreCase))
        {
            quest = new RivendellVillageQuest();
            quest.calculateReward(3);  // Difficulty for Pixie
        }
        else if (type.Equals("city", StringComparison.OrdinalIgnoreCase))
        {
            quest = new RivendellCityQuest();
            quest.calculateReward(8);  // Difficulty for Thief
        }
        return quest;
    }
}

// Concrete factory for Mordor quests
public class MordorQuestFactory : QuestFactory
{
    public Quest createQuest(string type)
    {
        Quest quest = null;
        if (type.Equals("village", StringComparison.OrdinalIgnoreCase))
        {
            quest = new MordorVillageQuest();
            quest.calculateReward(2);  // Difficulty for Giant Rat
        }
        else if (type.Equals("city", StringComparison.OrdinalIgnoreCase))
        {
            quest = new MordorCityQuest();
            quest.calculateReward(5);  // Difficulty for Bandit
        }
        return quest;
    }
}

// Quest generator that uses the abstract factory
public class QuestGenerator
{
    private QuestFactory questFactory;

    public QuestGenerator(QuestFactory questFactory)
    {
        this.questFactory = questFactory;
    }

    public void launchQuest(string type)
    {
        Quest quest = questFactory.createQuest(type);
        if (quest != null)
        {
            Console.WriteLine(quest.getDescription());
        }
        else
        {
            Console.WriteLine("No quest available for the specified type.");
        }
    }
}

// Main program to test the setup
public class Program
{
    public static void Main(string[] args)
    {
        QuestGenerator questGenerator = new QuestGenerator(new RivendellQuestFactory());
        questGenerator.launchQuest("village");
        questGenerator.launchQuest("city");

        questGenerator = new QuestGenerator(new MordorQuestFactory());
        questGenerator.launchQuest("village");
        questGenerator.launchQuest("city");
    }
}
