﻿using System.Xml;

InventorySystem inventorySystem = new InventorySystem();
PaymentSystem paymentSystem = new PaymentSystem();
OrderSystem orderSystem = new OrderSystem();

Item pokemonPack = new Item("Pokemon Pack",14.00, 5);
inventorySystem.addItem(pokemonPack);

paymentSystem.addFunds(20.0);

ShoppingCartFacade scFacade =
    new ShoppingCartFacade(inventorySystem, paymentSystem, orderSystem);

Console.WriteLine();
scFacade.checkout("Pokemon Pack", 2);

Console.WriteLine();
scFacade.checkout("Pokemon Pack", 2);

Console.WriteLine();
paymentSystem.addFunds(30.0);
scFacade.checkout("Pokemon Pack", 2);

Console.WriteLine();
scFacade.checkout("Pokemon Pack", 2);

public class ShoppingCartFacade
{
    InventorySystem ins;
    PaymentSystem ps;
    OrderSystem os;

    public ShoppingCartFacade(InventorySystem ins, PaymentSystem ps, OrderSystem os)
    {
        this.ins = ins;
        this.ps = ps;
        this.os = os;
    }
    public void checkout(string itemName, int quantity)
    {
        Console.WriteLine("Starting checkout process..");
        Console.WriteLine("Checking stock for Pokemon Pack...");
        if (ins.checkAvailability(itemName, quantity))
        {
            Item itemtoprocess = ins.getItem(itemName);
            Console.WriteLine($"Processing payment of {itemtoprocess.price}");
            if (ps.processPayment(itemtoprocess.price))
            {
                Console.WriteLine("Payemnt successful.");
                ins.reduceStock(itemName, quantity);
                Console.WriteLine("Order is confirmed");
                Console.WriteLine("Delivery details are set.");
            }
            else
            {
                Console.WriteLine("Payment unsucessful: Insufficient funds.");
            }
        }
        else
        {
            Console.WriteLine("Insufficient stock.");
        }
    }
}

public class Item
{
    public string name;
    public double price;
    public int quantity;

    public Item() { }
    public Item(string name, double price, int quantity) { 
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
    // constructor, getters and setters
}
public class OrderSystem
{
    public void confirmOrder()
    {
        Console.WriteLine("Order is confirmed.");
    }
    public void setDelivery()
    {
        Console.WriteLine("Delivery details are set.");
    }
}

public class InventorySystem
{
    private Dictionary<string, Item> inventory = new Dictionary<string, Item>();

    public void addItem(Item item)
    {
        inventory[item.name] = item;
    }

    public Item getItem(string name)
    {
        return inventory[name];
    }

    public bool checkAvailability(string itemName, int quantity)
    {
        Console.WriteLine($"Checking stock for {itemName}...");
        return inventory[itemName].quantity >= quantity;
    }

    public void reduceStock(string itemName, int quantity)
    {
        Console.WriteLine($"Reducing stock of {itemName} by {quantity}");
        inventory[itemName].quantity -= quantity;
    }
}

public class PaymentSystem
{
    private double balance = 0.0;
    public void addFunds(double amount)
    {
        Console.WriteLine($"Adding ${amount:N2} to balance.");
        balance += amount;
        Console.WriteLine($"Current funds ${balance:N2}");
    }

    public bool processPayment(double amount)
    {
        Console.WriteLine($"Processing payment of ${amount:N2}...");
        if (amount <= balance)
        {
            balance -= amount;
            Console.WriteLine("Payment successful");
            Console.WriteLine($"Funds left: ${balance:N2}");
            return true;
        }
        else {
            Console.WriteLine("Payment unsuccessful: insufficient funds");
            return false;
        }
    }
}

