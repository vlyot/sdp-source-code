﻿Player player = Player.GetInstance(50, 10, 8);

HealingPotion healing_potion = new HealingPotion(player, 10, 3);
ManaPotion mana_potion = new ManaPotion(player, 5, 3);
FireballSpell fireball_spell = new FireballSpell(player, 8);
HealingSpell healing_spell = new HealingSpell(player, 3);

Command drink_healing =
        new DrinkHealingPotionCommand(healing_potion);
Command drink_mana = new DrinkManaPotionCommand(mana_potion);
Command cast_fireball = new CastFireballCommand(fireball_spell);
Command cast_healing = new CastHealingCommand(healing_spell);

player.setCommand(drink_healing, 0);
player.setCommand(drink_mana, 1);
player.setCommand(cast_fireball, 2);
player.setCommand(cast_healing, 3);

player.Hp = 25;
player.Mp = 3;
Console.WriteLine($"Player has {player.Hp}/{player.maxHp} HP and {player.Mp}/{player.maxMp} MP.");

player.hotkeyPushed(0); // healing potion
player.hotkeyPushed(0); // healing potion
player.undoKeyPushed(); // undo
player.hotkeyPushed(0); // healing potion
player.hotkeyPushed(0); // healing potion
player.hotkeyPushed(0); // healing potion

player.hotkeyPushed(1); // mana potion
player.hotkeyPushed(1); // mana potion

player.hotkeyPushed(2); // fireball
player.hotkeyPushed(2); // fireball
player.hotkeyPushed(1); // mana potion
player.hotkeyPushed(2); // fireball
player.hotkeyPushed(3); // healing spell
player.undoKeyPushed(); // undo

public class Player
{
    private int hp;
    public int maxHp;
    private int mp;
    public int maxMp;
    private int magic_power;

    private Command[] commands;
    private Command lastCommand;

    private static Player _instance;
    private Player(int maxHp, int maxMp, int magicPower)
    {
        this.hp = maxHp;
        this.maxHp = maxHp;
        this.mp = maxMp;
        this.maxMp = maxMp;
        this.magic_power = magicPower;
        this.commands = new Command[12];
    }

    public static Player GetInstance(int maxHp, int maxMp, int magicPower)
    {
        if (_instance == null)
        {
            _instance = new Player(maxHp, maxMp, magicPower);
        }
        return _instance;
    }

    public int Hp
    {
        get => hp;
        set => hp = Math.Min(value, maxHp); // HP cannot exceed max HP
    }

    public int Mp
    {
        get => mp;
        set => mp = Math.Min(value, maxMp); // MP cannot exceed max MP
    }

    public int MagicPower => magic_power;

    public void setCommand(Command command, int slot)
    {
        commands[slot] = command;
    }

    public void hotkeyPushed(int slot)
    {
        if (commands[slot] != null)
        {
            commands[slot].execute();
            lastCommand = commands[slot];
        }
    }

    public void undoKeyPushed()
    {
        if (lastCommand != null)
        {
            lastCommand.undo();
        }
    }
}


public interface Command
{
    void execute();
    void undo();
}

public abstract class Potion
{
    protected Player player;
    protected int value;
    protected int doses;

    public Potion(Player player, int value, int doses)
    {
        this.player = player;
        this.value = value;
        this.doses = doses;
    }

    public abstract void drink();
    public abstract void undoDrink();
}

public abstract class Spell
{
    protected Player player;
    protected int cost;

    public Spell(Player player, int cost)
    {
        this.player = player;
        this.cost = cost;
    }

    public abstract void cast();
    public abstract void undoCast();
}

public class HealingPotion : Potion
{
    public HealingPotion(Player player, int value, int doses) : base(player, value, doses) { }

    public override void drink()
    {
        if (doses > 0)
        {
            doses--;
            player.Hp += value;
            Console.WriteLine($"Drank healing potion. Healed {value} HP. Remaining doses: {doses}");
        }
        else
        {
            Console.WriteLine("No healing potions left!");
        }
    }

    public override void undoDrink()
    {
        doses++;
        player.Hp -= value;
        Console.WriteLine($"Undid healing potion. Lost {value} HP. Doses restored: {doses}");
    }
}

public class ManaPotion : Potion
{
    public ManaPotion(Player player, int value, int doses) : base(player, value, doses) { }

    public override void drink()
    {
        if (doses > 0)
        {
            doses--;
            player.Mp += value;
            Console.WriteLine($"Drank mana potion. Restored {value} MP. Remaining doses: {doses}");
        }
        else
        {
            Console.WriteLine("No mana potions left!");
        }
    }

    public override void undoDrink()
    {
        doses++;
        player.Mp -= value;
        Console.WriteLine($"Undid mana potion. Lost {value} MP. Doses restored: {doses}");
    }
}

public class FireballSpell : Spell
{
    public FireballSpell(Player player, int cost) : base(player, cost) { }

    public override void cast()
    {
        if (player.Mp >= cost)
        {
            player.Mp -= cost;
            int damage = player.MagicPower * 2;
            Console.WriteLine($"Cast Fireball! Dealt {damage} damage. Remaining MP: {player.Mp}");
        }
        else
        {
            Console.WriteLine("Not enough MP to cast Fireball!");
        }
    }

    public override void undoCast()
    {
        player.Mp += cost;
        Console.WriteLine($"Undid Fireball cast. Restored {cost} MP.");
    }
}

public class HealingSpell : Spell
{
    public HealingSpell(Player player, int cost) : base(player, cost) { }

    public override void cast()
    {
        if (player.Mp >= cost)
        {
            player.Mp -= cost;
            player.Hp += player.MagicPower;
            Console.WriteLine($"Cast Healing! Restored {player.MagicPower} HP. Remaining MP: {player.Mp}");
        }
        else
        {
            Console.WriteLine("Not enough MP to cast Healing!");
        }
    }

    public override void undoCast()
    {
        player.Mp += cost;
        player.Hp -= player.MagicPower;
        Console.WriteLine($"Undid Healing cast. Restored {cost} MP and lost {player.MagicPower} HP.");
    }
}
public class DrinkHealingPotionCommand : Command
{
    private HealingPotion potion;

    public DrinkHealingPotionCommand(HealingPotion potion)
    {
        this.potion = potion;
    }

    public void execute()
    {
        potion.drink();
    }

    public void undo()
    {
        potion.undoDrink();
    }
}

public class DrinkManaPotionCommand : Command
{
    private ManaPotion potion;

    public DrinkManaPotionCommand(ManaPotion potion)
    {
        this.potion = potion;
    }

    public void execute()
    {
        potion.drink();
    }

    public void undo()
    {
        potion.undoDrink();
    }
}

public class CastFireballCommand : Command
{
    private FireballSpell spell;

    public CastFireballCommand(FireballSpell spell)
    {
        this.spell = spell;
    }

    public void execute()
    {
        spell.cast();
    }

    public void undo()
    {
        spell.undoCast();
    }
}

public class CastHealingCommand : Command
{
    private HealingSpell spell;

    public CastHealingCommand(HealingSpell spell)
    {
        this.spell = spell;
    }

    public void execute()
    {
        spell.cast();
    }

    public void undo()
    {
        spell.undoCast();
    }
}
