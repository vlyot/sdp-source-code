﻿using My_console_app;

Character character = new Warrior();

Weapon sword = new Sword();
Weapon axe = new Axe();

character.MyWeapon = sword;
character.attack();
character.MyWeapon = axe;
character.attack();
