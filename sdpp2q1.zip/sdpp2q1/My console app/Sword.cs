﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_console_app
{
    class Sword : Weapon
    {
        public void attack()
        {
            System.Console.WriteLine("Attack with Sword");
        }
    }

}
