﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_console_app
{
    class Axe : Weapon
    {
        public void attack()
        {
            System.Console.WriteLine("Attack with Axe");
        }
    }

}
