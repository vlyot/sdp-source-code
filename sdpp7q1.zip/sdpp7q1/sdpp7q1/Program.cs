﻿Player player = Player.GetInstance();

// Call Player methods
player.SetCommand();
player.UndoKeyPush();
player.HotKeyPush(5);

// Ensure only one instance exists
Player anotherPlayer = Player.GetInstance();
Console.WriteLine(object.ReferenceEquals(player, anotherPlayer)); // True
class Player
{
    private int hp;
    private int maxHp;
    private int mp;
    private int maxMp;
    private int magic_power;

    private static Player _instance;
    private Player() { }
    public static Player GetInstance()
    {
        if (_instance == null)
        {
            _instance = new Player();
        }
        return _instance;
    }
    public void SetCommand()
    {
        // Implementation for setting a command
        Console.WriteLine("SetCommand executed.");
    }

    // Public method to handle undo action
    public void UndoKeyPush()
    {
        // Implementation for undoing the last action
        Console.WriteLine("UndoKeyPush executed.");
    }

    // Public method to handle hotkey actions
    public void HotKeyPush(int slot)
    {
        // Implementation for hotkey actions
        Console.WriteLine($"HotKeyPush executed for slot {slot}.");
    }
}