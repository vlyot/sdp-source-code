﻿// MediaPlayer Interface
public interface MediaPlayer
{
    void play(MediaFile mediaFile);
}

// MediaFile Class
public abstract class MediaFile
{
    public string Name { get; private set; }

    public MediaFile(string name)
    {
        Name = name;
    }
}

// MP3File Class
public class MP3File : MediaFile
{
    public MP3File(string name) : base(name) { }
}

// MP4File Class
public class MP4File : MediaFile
{
    public MP4File(string name) : base(name) { }
}

// MP3Player Class
public class MP3Player
{
    public void playMP3(string mp3FileName)
    {
        Console.WriteLine($"Playing MP3 File: {mp3FileName}");
    }
}

// MP4Player Class
public class MP4Player
{
    public void playMP4(MP4File mP4File)
    {
        decompress(mP4File);
        Console.WriteLine($"Playing MP4 File: {mP4File.Name}");
    }

    public void decompress(MP4File mP4File)
    {
        Console.WriteLine($"Decompressing MP4 File: {mP4File.Name}");
    }
}

// MP3PlayerAdapter Class
public class MP3PlayerAdapter : MediaPlayer
{
    private MP3Player mp3Player;

    public MP3PlayerAdapter(MP3Player mp3Player)
    {
        this.mp3Player = mp3Player;
    }

    public void play(MediaFile mediaFile)
    {
        if (mediaFile is MP3File mp3File)
        {
            mp3Player.playMP3(mp3File.Name);
        }
        else
        {
            Console.WriteLine("Invalid media file for MP3 Player.");
        }
    }
}

// MP4PlayerAdapter Class
public class MP4PlayerAdapter : MediaPlayer
{
    private MP4Player mp4Player;

    public MP4PlayerAdapter(MP4Player mp4Player)
    {
        this.mp4Player = mp4Player;
    }

    public void play(MediaFile mediaFile)
    {
        if (mediaFile is MP4File mp4File)
        {
            mp4Player.playMP4(mp4File);
        }
        else
        {
            Console.WriteLine("Invalid media file for MP4 Player.");
        }
    }
}

// Main Program
class Program
{
    static void Main(string[] args)
    {
        MediaFile soundFile = new MP3File("song.mp3");
        MediaFile movieFile = new MP4File("movie.mp4");

        MP3Player mP3Player = new MP3Player();
        MP4Player mP4Player = new MP4Player();

        MediaPlayer mp3Adapter = new MP3PlayerAdapter(mP3Player);
        MediaPlayer mp4Adapter = new MP4PlayerAdapter(mP4Player);

        MediaPlayer mp;

        // Playing MP3 File
        mp = mp3Adapter;
        mp.play(soundFile);

        // Playing MP4 File
        mp = mp4Adapter;
        mp.play(movieFile);
    }
}
