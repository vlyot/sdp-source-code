﻿DinerMenu mcdodo = new DinerMenu();
mcdodo.addItem(new MenuItem("Hamburger", 2.00f));
mcdodo.addItem(new MenuItem("McSpicy", 3.50f));
mcdodo.addItem(new MenuItem("Fries", 1.50f));

Iterator iter = mcdodo.createIterator(2.50f);
while (iter.hasNext())
{
    MenuItem item = (MenuItem)iter.next();
    Console.WriteLine($"{item.name,12}   ${item.price:N2}");
}

public class MenuItem
{
    public string name;
    public float price;

    public MenuItem(string n, float p)
    {
        this.name = n;
        this.price = p;
    }
    // other implementations, e.g., constructor
}

public class DinerMenu
{
    int numberOfItems = 0;
    MenuItem[] menuItems = new MenuItem[20];

    public int NumberOfItems { get { return numberOfItems; } }

    public Iterator createIterator(float maxPrice)
    {
        return new PriceIterator(this, maxPrice);
    }

    public void addItem(MenuItem item)
    {
        menuItems[numberOfItems++] = item;
    }

    public MenuItem getItem(int position) { return menuItems[position]; }

    // other implementations, e.g., constructor, addItem(), getItem() etc.
}
public interface Iterator
{
    public bool hasNext();
    public object next();
}
public class PriceIterator : Iterator
{
    private DinerMenu dinerMenu;
    int position = 0;
    float maxPrice;

    public PriceIterator(DinerMenu dinerMenu, float mp)
    {
        this.dinerMenu = dinerMenu;
        this.maxPrice = mp;
    }

    public bool hasNext()
    {
        while (position < dinerMenu.NumberOfItems)
        {
            // Iterate through the menu items until an item that meets the condition is found or we reach the end
            while (position < dinerMenu.NumberOfItems)
            {
                MenuItem currentItem = dinerMenu.getItem(position);
                if (currentItem != null && currentItem.price <= maxPrice)
                {
                    return true; // Found an item that meets the condition
                }
                position++; // Move to the next item
            }
        }
        return false;
    }

    // Returns the next MenuItem that meets the maxPrice condition
    public object next()
    {
        if (position >= dinerMenu.NumberOfItems)
        {
            throw new InvalidOperationException("No more items."); // Error if next is called without a valid item
        }

        MenuItem menuItem = dinerMenu.getItem(position); // Get the current item
        position++; // Move the position for the next iteration
        return menuItem; // Return the current item
    }
}
